export default class CartasSystem {
    constructor() {
        // Base de datos oficial de los 6 personajes balanceados
        this.personajesBase = {
            vexa:    { id: 'vexa',    nombre: 'Vexa',    clase: 'HACKER',  atk: 15, def: 20, hp: 100 },
            miner0:  { id: 'miner0',  nombre: 'M1N3R-0',  clase: 'HACKER',  atk: 12, def: 25, hp: 110 },
            kaelen:  { id: 'kaelen',  nombre: 'Kaelen',  clase: 'PILOTO',  atk: 22, def: 12, hp: 90  },
            akira:   { id: 'akira',   nombre: 'Akira',   clase: 'PILOTO',  atk: 20, def: 15, hp: 95  },
            nova:    { id: 'nova',    nombre: 'Nova',    clase: 'ENTIDAD', atk: 10, def: 30, hp: 120 },
            pepex:   { id: 'pepex',   nombre: 'Pepe-X',  clase: 'ENTIDAD', atk: 14, def: 18, hp: 105 }
        };
        this.progresoHabilidades = {
            puntosMision: 5,
            vexa: { nodosComprados: 0, bonusAtk: 0, bonusDef: 0 },
            miner0: { nodosComprados: 0, bonusAtk: 0, bonusDef: 0 },
            kaelen: { nodosComprados: 0, bonusAtk: 0, bonusDef: 0 },
            akira: { nodosComprados: 0, bonusAtk: 0, bonusDef: 0 },
            nova: { nodosComprados: 0, bonusAtk: 0, bonusDef: 0 },
            pepex: { nodosComprados: 0, bonusAtk: 0, bonusDef: 0 }
        };
    }

    mejorarNodo(personajeId) {
        let progreso = this.progresoHabilidades[personajeId];
        if (this.progresoHabilidades.puntosMision > 0 && progreso.nodosComprados < 5) {
            this.progresoHabilidades.puntosMision--;
            progreso.nodosComprados++;
            progreso.bonusAtk += 3;
            progreso.bonusDef += 2;
            return true;
        }
        return false;
    }
}
